import pandas as pd
import calendar
from pprint import pprint

fn = 'c19_timeseries.csv'

def convert_to_dayname(row):
    return calendar.day_name[row.weekday()]

df = pd.read_csv(fn,
    usecols=['date', 'area', 'cases'],
    parse_dates=['date'])

allCC = df[df['area'] == 'Contra Costa'].copy()

allCC['cases'] = allCC['cases'].astype(int)

allCC['dayOfWeek'] = allCC['date'].apply(convert_to_dayname)

finaldf = allCC.groupby('dayOfWeek').sum().sort_values(by='cases', ascending=False).reset_index()
pprint(finaldf)

maxCountDay = finaldf.loc[0]['dayOfWeek']
maxCountCases = finaldf.loc[0]['cases']

minCountDay = finaldf.loc[len(finaldf.index) - 1]['dayOfWeek']
minCountCases = finaldf.loc[len(finaldf.index) - 1]['cases']

avgWeekends = allCC[allCC['dayOfWeek'].isin(['Saturday', 'Sunday'])]['cases'].mean()
avgWeekdays = allCC[~allCC['dayOfWeek'].isin(['Saturday', 'Sunday'])]['cases'].mean()

print(f"The day of week with the max number of reported cases is: {maxCountDay} ({maxCountCases} cases)")
print(f"The day of week with the min number of reported cases is: {minCountDay} ({minCountCases} cases)")

if avgWeekdays>avgWeekends:
    print("Averages were higher on weekdays.")
elif avgWeekdays<avgWeekends:
    print("Averages were higher on weekends.")
else:
    print("Averages were the same.")